<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of StatusColeta
 *
 * @author Bruno
 */
class Application_Model_StatusColeta extends SOSMalas_Db_Mapper{
    
    protected $_name = 'status_coleta';
    protected $_primary = 'id_status_coleta';
    
}