<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of Const
 *
 * @author Bruno
 */
class SOSMalas_Const {

    const DATE_FORMAT_DB = 'Y-m-d';
    const DATE_FORMAT_VIEW = 'd-m-Y';
    
    const MSG01 = 'Operação realizada com sucesso';
    const MSG02 = 'Erro ao executar a opeção';
    const MSG03 = 'Verifique seu formulário, os campos obrigatórios não foram preenchidos';
}