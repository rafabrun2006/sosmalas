<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Objetivo: Reunir regras.
 * 
 * Description Reuni regras para classes models que necessitam de regras para
 * seu funcionamento.
 * 
 * @author Bruno <rafabrun2006@gmail.com>
 */
class Owen_Db_ModelRoles {
    
    //Palavras ignoradas nos campos de busca textual
    public static $rolesWordPreposition = array('para', 'de', 'que', 'em', ',', '.', '!');
    
}
